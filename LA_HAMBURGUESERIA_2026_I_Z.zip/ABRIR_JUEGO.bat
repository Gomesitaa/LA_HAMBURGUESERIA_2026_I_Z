@echo off
start "" "%~dp0LA_HAMBURGUESERIA_2026_I_Z.html"
